package com.example.transportfirm.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "mechanics_info")
@Data
public class MechanicInfo {

    @Id
    @GeneratedValue
    @Column(columnDefinition = "uuid")
    private UUID id;

    @OneToOne
    @JoinColumn(name = "employee_id", nullable = false)
    @JsonBackReference("employee-mechanic")
    private Employee employee;

    @JsonIgnore
    @OneToMany(mappedBy = "mechanic")
    private List<TruckGroup> mechanicGroups = new ArrayList<>();
}
