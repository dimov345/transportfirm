package com.example.transportfirm.repository;

import com.example.transportfirm.entity.MechanicInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface MechanicRepository extends JpaRepository<MechanicInfo, UUID> {
}
