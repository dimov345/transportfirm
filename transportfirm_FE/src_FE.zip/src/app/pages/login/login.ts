import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../../core/auth/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})
export class Login {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  loading = false;
  errorMsg = '';

  form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]]
  });

  submit() {
    this.errorMsg = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;

    const email = this.form.value.email!.trim();
    const password = this.form.value.password!;

    this.auth.login({ email, password }).subscribe({
      next: () => {
        const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/';
        this.router.navigateByUrl(returnUrl);
      },
      error: (err: HttpErrorResponse) => {
        // backend: 403 + firstLoginRequired=true
        const firstLoginRequired =
          err?.status === 403 && (err?.error?.firstLoginRequired === true || err?.error?.firstLoginRequired === 'true');

        if (firstLoginRequired) {
          this.errorMsg = 'Първо влизане: трябва да смениш паролата (backend върна firstLoginRequired).';
          // ако после искаш, правим /first-login страница + endpoint wiring
          // this.router.navigate(['/first-login'], { queryParams: { email } });
        } else {
          this.errorMsg = err?.error?.message || 'Грешен email или парола.';
        }
        this.loading = false;
      },
      complete: () => (this.loading = false)
    });
  }
}
